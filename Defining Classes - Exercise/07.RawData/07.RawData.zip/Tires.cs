﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.RawData
{
    public class Tires
    {
        public int Age { get; set; }
        public double Pressure { get; set; }
    }
}
